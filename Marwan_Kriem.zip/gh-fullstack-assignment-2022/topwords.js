/* main moudels */
const fs = require("fs");
const helpers = require('./helpers');
const fileName = process.argv[2];

/* variables */
var fileContent = null; // to get the file content.
var words = new Array(); // to save the files words.
var reg = null; // an auxiliary var to be overwritten every time we need to use regex.
var repeatedWords = new Array(); // to save the final result.


/* asynchronous task to check if the file is larger than 2GB and exit if true */
fs.stat(fileName, (err, data) => {
  if (err) {
    console.log(err.message);
    process.exit()
  }
  data.size / (1024 * 1024 * 1024) > 2 ? process.exit() : "" ;
});


/*all the logic goes here*/
try {
  fileContent = fs.readFileSync(fileName, "ascii").toString(); // read the file and convert it to string.
  fileContent.length > 4096 ? process.exit() : ""; // see if the characters is larger than 4096
  fileContent = fileContent.replaceAll(/\n/g, " ").split("").reverse().join(""); // replace any break line with a space and reverse all the files words.
  words = fileContent.split(" "); // save all the words in array.
  words = words.map(filterNonletrNum).filter(filterStringLength); //filter every word and make sure that the words passes every rule mentioned in the assignment.
  
  words.forEach((val) => {
    reg = new RegExp(`(?:^|\\W)${val}(?![a-z0-9])`, "gi"); // make a regex for every word and make sure that starts with the given word and not ends with num or car
    if (fileContent.match(reg) != null) { //check if there's any matches in the reversed string from the original file.
        obj = { word: val, repeated: fileContent.match(reg).length }; // save the word and the repeated number in object form.
        if (fileContent.match(reg).length > 1 && !helpers.containsObj(obj, repeatedWords)) { // check that the word is not included before.
        repeatedWords.push(obj);// push it into the array
        }
    }
  });

} catch (error) {
  console.log(error.message);
}


/* remove any character that is not a number or letter to a given string */
function filterNonletrNum(string) {
 return string.replaceAll(/[^0-9a-z]/gi, '').toLowerCase();
}

/* check if the given string has more than 2 characters */
function filterStringLength(string) {
  return string.length > 2;
}

/* sort all the repeated word in descending form */
repeatedWords.sort(helpers.compare);


/* output the result */
if (repeatedWords.length > 0) {
  repeatedWords[0].repeated == (repeatedWords[1] ? repeatedWords[1].repeated : 0) // most 2 consecutive reversed words that appear in the file.
  ? 
  console.log(`${repeatedWords[0].word} ${repeatedWords[1].word} ${repeatedWords[0].repeated}`) 
  :
  console.log(`${repeatedWords[0].word} ${repeatedWords[0].repeated}`); // most consecutive reversed word that appear in the file.
} else {
  console.log("this file has no repeated words.");
}