# Notes

The program uses array to save the results which contains the most consecutive words in descending order ,
so we can use that in the second optional part, so the first part of the assignment includes the second one,
and there's no need to repeat it in a separated js file.

The program will automatically output one word if in the tested file has no more than one consecutive word,
and if it's has two consecutive word that appear the most it will output two.

# About (helpers.js)

this file includes general helpers function that can be used in any js program.