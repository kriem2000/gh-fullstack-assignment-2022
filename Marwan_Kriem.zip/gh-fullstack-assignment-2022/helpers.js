const containsObj = (obj , array) => {
    let res = false;
    array.forEach((val) => {
      if (val.word === obj.word) {
        res = true;
        return;
      }
    });
    return res;
  }

const compare = ( a, b ) => {
    if ( a.repeated < b.repeated ){
      return 1;
    }
    if ( a.repeated > b.repeated ){
      return -1;
    }
    return 0;
  }

  exports.containsObj = containsObj;
  exports.compare = compare;
