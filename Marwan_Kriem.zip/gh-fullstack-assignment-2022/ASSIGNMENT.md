# Fullstack Software Engineer Assignment

This file describes your assignment.

Your task is to create a program that meets the requirements stated on this
document.

Please use git in order to commit your progress on this assignment. Once you
completed the assignment, zip the contents of the folder (including git history)
and send it to us by e-mail. The name of the zip file must be formed using
the first letter of your name followed by your first surname and end with
.zip extension.

We encourage you to add a README.md in case you want to include any relevant 
information for the reviewers of the assignment. Reviewers will only have access
to the .zip file (won't be reading any information from the e-mails we exchange).

GameHouse will value good software practices, appropriate algorithms and data
structures, good coding style, error handling and effective usage of CPU & RAM
when running the program itself. Completing the optional part will also be valued.

## Assignment

### Summary

Make a command-line program that reads a file (passed as the first argument),
reverses all words in the file and prints the reversed word that appears the
most along with the number of times that reversed word appears.

Make sure the program meets the following requirements:

### Requirements

- The program must be done in nodejs (must work with node 12, 14 and 16) (done).

- The program must be named: topwords.js (done).

- The program must be self-contained, cannot use any third-party module/package
  outside of the ones that node itself provides (e.g you can use 'path' or 'fs'
  or similar, but not packages from npmjs.com) (done).

- The program must accept only one argument, the file to be read (done).

- File contents can be in any format or encoding, even in binary (done)

- The program must treat file contents as ASCII characters (done)

- A single file won't be larger than 2GB (done)

- All words in a file are guaranteed not to be larger than 4096 characters (done)

- A word is any consecutive sequence formed only of ASCII letters & numbers (
  e.g 'abc', 'abc123', '123', 'Aba12', ...) (done)

- Anything that is not a letter or a number must be considered a separator
  and ignored (done)

- Words must be treated case-insensitive ('word', 'WORD', 'WoRD' are equivalent) (done)

- All words equal or smaller than 2 characters must be ignored (you can treat
  them as part of the separators themselves) (done)

- Consecutive separators must be treated as a single separator character (e.g
  'word1.-+-.word2' is equivalent to 'word1 word2') (done)

- The program must reverse all words and count the frequency of those reversed
  words in order to print, in lowercase, the reversed word that appears the most
  in the file along with the number of times that it appears on the file. (done)

- If there are more than one reversed word with the same topword count, any of
  those words will be considered a valid answer. Only one must be printed,
  though. (done)

### Example

Imagine you have **file.txt** with the following contents:

    A First Example: this is an example... do you like it?

So the output of the program would be:
  
    $ node topwords.js file.txt
    elpmaxe 2

Please note that we are providing some example files with this assignment, but 
the reviewers will test your program with other files as well.

## Optional (done)

You are free to skip this part of the assignment if you are tight on time,
but be aware that if you decide to skip it, you will get questioned about how
would you have approached this optional part on our first interview.

### Summary

Make a program that counts and outputs the combination of two consecutive
reversed words that appear the most in a file.

### Requirements

- Same rules as before. Consider all characters and invalid words (the ones with
less or equal than 2 chars) as a single separator.

- The program must be named: topwords2.js

### Example

Imagine you have **file2.txt** with the following contents:

    A Second Example: this is second 2 example... do you like it?

The output of the program would be:
  
    $ node topwords2.js file2.txt
    elpmaxe dnoces 2
